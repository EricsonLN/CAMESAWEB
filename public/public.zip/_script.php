<!-- Scripts externos -->
<script src="js/mycustomjquery.js"></script>
<script src="js/mycustomjquerybanner.js"></script>
<script src="js/mycustomjqueryProducto.js"></script>
<script src="js/mycustomqueryproducto.js"></script>
<script src="js/slidercontacto.js"></script>
<!-- Scripts propios -->
<script src="js/nav.js"></script>
<!-- <script src="js/js_form.js"></script> -->