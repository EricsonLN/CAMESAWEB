<script src="js/lightbox-plus-jquery.min.js"></script>
  <script src="js/lightbox.min.js"></script>
<script src="js/slick/slick.js"></script>
<script src="js/mycustomjquery.js"></script>
<script src="js/mycustomjquerybanner.js"></script>
<script src="js/mycustomjqueryProducto.js"></script>
<script src="js/nav.js"></script>
<script src="js/mycustomqueryproducto.js"></script>