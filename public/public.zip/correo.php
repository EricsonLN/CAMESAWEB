<?php

    if(isset($_POST['btnEnviar'])){
        if(!empty($_POST['txtnombre']) && !empty($_POST['txtemail']) && !empty($_POST['txtTelefono']) && !empty($_POST['txtAsunto']) && !empty($_POST['txtMensaje'])  ){

        }
    }
?>