<header class="main-header">
    <div class="main-header__container container">
        <div class="main_header__item">
            <i class="fas fa-map-marker-alt"></i>
            <p>Pricipal: Av:jhon F.Kennedy 1054 - Moshoqueque-JLO <br>Sucursal:Car: Panamericana KM. 965 frente a Ferrenor costado del grifo de Olmos - Olmos - Lambayeque</p>
        </div>
        <div class="main_header__item">
            <i class="fas fa-phone"></i>
            <a href="tel:+51938947610"><p>938 947 610/923 310 683</p></a>
        </div>
        <div class="main_header__item">
            <a href="#"><i class="fab fa-whatsapp"></i></a>
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            
           
        </div>
    </div>
</header>