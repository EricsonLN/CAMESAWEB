$("#Enviar").click(function () {
  var nombre = document.getElementById("txtnombre").value;
  var email = document.getElementById("txtemail").value;
  var telefono = document.getElementById("txtTelefono").value;
  var asunto = document.getElementById("txtAsunto").value;
  var mensaje = document.getElementById("txtMensaje").value;
  var button = document.getElementById("btnEnviar").value;

  var ruta = "Nom=" + nombre + "& Apellidos=" + a;
});
