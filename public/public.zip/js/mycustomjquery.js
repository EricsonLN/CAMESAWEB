$(document).ready(function(){
    
    /*=====================Slider Principal==========================*/
    $(".slider-gallery").slick({
        dots:               true,
        infinite:           true,
        slidesToShow:       1,
        slidesToScroll:     1,
        autoplay:           false,
        arrows:             false,
        speed:              2000,
        autoplaySpeed:      5000,
    });
   

  

    
    /*===================Sky====================*/
    
    
   
    
})