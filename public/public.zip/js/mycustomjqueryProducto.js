$(document).ready(function () {
  /*=====================Slider Principal==========================*/
  $(".slider-mainProductos").slick({
    dots: false,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: false,
    arrows: true,
    speed: 2000,
    autoplaySpeed: 5000,
  });

  /*===================Sky====================*/
});
