$(document).ready(function(){
    
    /*=====================Slider Principal==========================*/
    $(".slider-main").slick({
        dots:               false,
        infinite:           true,
        slidesToShow:       1,
        slidesToScroll:     1,
        autoplay:           false,
        arrows:             false,
        speed:              2000,
        autoplaySpeed:      5000,
    });
   

  

    
    /*===================Sky====================*/
    
    
   
    
})