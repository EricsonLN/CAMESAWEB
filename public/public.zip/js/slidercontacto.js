$(document).ready(function () {
    /*=====================Slider Principal==========================*/
    $(".main-formulario__img").slick({
      dots: false,
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      arrows: false,
      speed: 2000,
      autoplaySpeed: 5000,
    });
  
    /*===================Sky====================*/
  });