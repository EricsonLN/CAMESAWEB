<!-- ico -->
<link rel="icon" href="assets/img/ico/logoico.jpg">
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
<!-- Slick -->
<link rel="stylesheet" href="js/slick/slick.css" />
<link rel="stylesheet" href="js/slick/slick-theme.css" />
<script src="js/slick/slick.js"></script>
<!-- Lightbox -->
<link rel="stylesheet" href="css/lightbox.min.css" />
<script src="js/lightbox.min.js"></script>
<!-- Fontawesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous" />
<!-- Normalize -->
<link rel="stylesheet" href="css/normalize.css">
<!-- Styles -->
<link rel="stylesheet" href="assets/css/style.css">
