<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('linkeos.php') ?>
    <title>Productos</title>
</head>

<body>
    <?php include('_secciones2.php') ?>
    <?php include('_layout.php') ?>
    <?php include('_script.php') ?>
</body>

</html>